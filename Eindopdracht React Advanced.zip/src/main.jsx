import React from 'react';
import ReactDOM from 'react-dom/client';
import { EventPage } from './pages/EventPage';
import { EventsPage } from './pages/EventsPage';
import { AboutUs } from './pages/AbousUs';
import { Provider } from './components/ui/provider'
import { EventsProvider } from './EventContext';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Root } from './components/Root';


const router = createBrowserRouter([
    {
        path: '/',
        element: <Root />,
        children: [
            {
                path: '/',
                element: <EventsPage />,
                // loader: postListLoader,
            },
            {
                path: '/event/:eventId',
                element: <EventPage />,
                // loader: postLoader,
                // action: addComment,
            },
                        {
                path: '/aboutus',
                element: <AboutUs />,
                // loader: postLoader,
                // action: addComment,
            },
        ],
    },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
        <Provider>
        <EventsProvider>
            <RouterProvider router={router} />
        </EventsProvider>
        </Provider>
    </React.StrictMode>,
);