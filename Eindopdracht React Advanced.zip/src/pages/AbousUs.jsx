import { Text } from "@chakra-ui/react";

export const AboutUs = () => {
    
return (
<Text>This page is under construction..</Text>

)};