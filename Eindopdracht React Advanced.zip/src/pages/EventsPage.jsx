import {
  Heading,
  Box,
  Center,
  Flex,
  Field,
  SimpleGrid,
  Input,
  Text,
  Stack,
} from "@chakra-ui/react";
import { useState, useContext } from "react";
import { EventCard } from "../components/EventCard";
import { EventContext } from "../EventContext.jsx";
import { CategoryFilter } from "../components/CategoryFilter";
import {EventSkeleton} from "../components/EventSkeleton";

export const EventsPage = () => {
  const { events, categories, loading, fetchData, deleteEvent } =
    useContext(EventContext);

  const [inputValue, setInputValue] = useState("");
  const [selected, setSelected] = useState([]);
  const handleSearchChange = (e) => {
    setInputValue(e.target.value);
  };

  const visibleEvents = events.filter((event) => {
    const foundEvents = event.title
      .toLowerCase()
      .includes(inputValue.toLowerCase().trim());

    const matchesCategory =
      selected.length === 0 ||
      event.categoryIds?.some((categoryId) => selected.includes(categoryId));

    return foundEvents && matchesCategory;
  });


  return (
    <Box minH="100vh" _light={{ bg: "purple.100" }}>
      <Center flexDir="column" pl={6} pr={6} pb={6}>
        <Heading
          fontSize={{ base: 35, md: 40 }}
          p={10}
          _light={{ color: "purple.800" }}
          _dark={{ color: "purple.100" }}
        >
          List of events
        </Heading>

        <Box
          w={{ base: "90%", md: "50%" }}
          bg="purple.200"
          borderRadius={5}
          margin={4}
          padding={3}
        >
          <Field.Root>
            <Field.Label color="purple.800" marginBottom={1}>
              Search for an event
            </Field.Label>

            <Input
              type="text"
              variant="outline"
              value={inputValue}
              onChange={handleSearchChange}
              placeholder="Type in a keyword for your search"
            />
          </Field.Root>
        </Box>

        <Flex
          w={{ base: "90%", md: "30%" }}
          bg="purple.200"
          borderRadius={5}
          margin={4}
          padding={3}
          justify="center"
        >
          <Stack>
            <Text textAlign="center" color="purple.800">
              Or filter by category
            </Text>
            {!loading && (
              <CategoryFilter
                selected={selected}
                setSelected={setSelected}
                categories={categories}
              />
            )}
          </Stack>
        </Flex>

           {loading ? (
  <SimpleGrid columns={{ base: 1, sm: 2, lg: 4 }} gap={{ base: 4, md: 6 }} w="100%">
    {Array.from({ length: 8 }).map((_, i) => (
      <EventSkeleton key={i} />
    ))}
  </SimpleGrid>
) : (
          <SimpleGrid
            columns={{ base: 1, sm: 2, lg: 4 }}
            gap={{ base: 4, md: 6 }}
            w="100%"
          >
            {visibleEvents.length > 0 ? (
              visibleEvents.map((event) => (
                <EventCard
                  key={event.id}
                  event={event}
                  deleteEvent={deleteEvent}
                  categories={categories}
                  fetchData={fetchData}
                />
              ))
            ) : (
              <Flex align="center" justify="center">
                <Text>Sorry, we couldn&apos;t find any events.</Text>
              </Flex>
            )}
          </SimpleGrid>
        )}

      </Center>
    </Box>
  );
};
