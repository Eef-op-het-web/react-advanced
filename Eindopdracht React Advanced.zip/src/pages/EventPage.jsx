import { Heading, Box, Text, Image, Flex, Tag, Stack, Button } from "@chakra-ui/react";
import { useParams } from "react-router-dom";
import { useContext } from "react";
import { EventContext } from "../EventContext.jsx";
import { DeleteEventModal } from "../components/DeleteEventModal";
import { EditEventModal } from "../components/EditEventModal";
import { Toaster, toaster } from "../components/ui/toaster";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export const EventPage = () => {
  const { events, categories,fetchData, deleteEvent, loading, processCategories } = useContext(EventContext);
  const { eventId } = useParams();
  
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const event = events.find((event) => String(event.id) === eventId);
  const navigate = useNavigate();

  if (!event) {
    return <p>Event niet gevonden</p>;
  }

  return (
    <Box>
      <Stack>
        <Heading
          _light={{ color: "purple.800" }}
          _dark={{ color: "purple.100" }}
          textAlign="center"
          fontStyle="bold"
          size={{ base: "md", md: "3xl" }}
          padding={1}
        >
          {event.title}
        </Heading>

        <Text
          fontSize="1.5rem"
          _light={{ color: "purple.800" }}
          _dark={{ color: "purple.100" }}
          fontStyle="bold"
          textAlign="center"
        >
          {event.description}
        </Text>
        <Image
          src={event.image}
          w="full"
          h="25rem"
          objectFit="cover"
          borderRadius="lg"
          alt={event.title}
        />
        <Flex justify="center" gap={10}>
          <Text
            fontSize={20}
            _light={{ color: "purple.800" }}
            _dark={{ color: "purple.100" }}
          >
            Start Time: {event.startTime.slice(11, 16)}
          </Text>
          <Text
            fontSize={20}
            _light={{ color: "purple.800" }}
            _dark={{ color: "purple.100" }}
          >
            End Time: {event.endTime.slice(11, 16)}
          </Text>
        </Flex>
        <Flex justify="center">
        <Text
          fontSize={20}
          _light={{ color: "purple.800" }}
          _dark={{ color: "purple.100" }}
        >
          Location: {event.location}
        </Text>
        </Flex>

         <Flex justify="center" gap={2} wrap="wrap" mt={2} mb={2}>
              {event.categoryIds.map((categoryId) => (
                <Tag.Root
                  p={{ base: 1.5, md: 2 }}
                  size={{ base: "sm", md: "md" }}
                  variant="solid"
                  bg="blue.100"
                  color="blue.800"
                  // key={categories.id}
                >
                  <Tag.Label>{categories[(categoryId-1)]?.name}</Tag.Label>
                </Tag.Root>
              ))}
            </Flex>
      <Button onClick={()=>{setIsEditModalOpen(true)}}>Edit event</Button>
           <Button onClick={()=>{setIsDeleteModalOpen(true)}}>Delete event</Button>
      </Stack>

     {!loading && ( 
        <EditEventModal
          open={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          eventId={eventId}
          fetchData={fetchData}
          processCategories={processCategories}
   />
  )}  
        <Toaster />  

<DeleteEventModal
  eventId={eventId}
  open={isDeleteModalOpen}
  onClose={() => setIsDeleteModalOpen(false)}
  cancel={() => setIsDeleteModalOpen(false)}
  finish={async () => {
    try {
      await deleteEvent(eventId);
 navigate('/');
 fetchData();
      toaster.create({
        title: "Success",
        description: "Event has been deleted!",
        type: "success",
      });
    } catch (error) {
      console.error("Failed to delete event:", error);
      toaster.create({
        title: "Error",
        description: "Failed to delete event.",
        type: "error",
      });
    }
  }}
/>
          <Toaster />  
    </Box>


  );
};
