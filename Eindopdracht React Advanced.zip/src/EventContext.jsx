import { createContext, useState, useEffect } from "react";

export const EventContext = createContext();

export const EventsProvider = ({ children }) => {
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);

      const [eventsResponse, categoriesResponse] = await Promise.all([
        fetch("http://localhost:3000/events"),
        fetch("http://localhost:3000/categories"),
      ]);

      if (!eventsResponse.ok || !categoriesResponse.ok) {
        throw new Error("Failed to fetch events or categories");
      }

      const eventsData = await eventsResponse.json();
      const categoriesData = await categoriesResponse.json();

      setEvents(eventsData);
      setCategories(categoriesData);
    } catch (error) {
      console.error("Fetching data failed:", error);
    } finally {
      setLoading(false);
    }
  };

useEffect(() => {
  fetchData();
}, []);

const processCategories = async (input) => {

  const names = [
    ...new Set(
      input
        .split(",")
        .map((name) => name.trim().toLowerCase())
        .filter(Boolean)
    ),
  ];

  const categoryIds = [];

  for (const name of names) {
    const existing = categories.find(
      (category) => category.name.toLowerCase() === name
    );

    if (existing) {
     categoryIds.push(existing.id);
    } else {
          const response = await fetch(
        "http://localhost:3000/categories",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name }),
        }
      );

      if (!response.ok) {
        throw new Error("Could not save category: " + name);
      }

      const newCategory = await response.json();

        categoryIds.push(newCategory.id);

        categories.push(newCategory);
    }
  }

  return categoryIds;
};

const deleteEvent = async (eventId) => {
  const response = await fetch(
    `http://localhost:3000/events/${eventId}`,
    {
      method: "DELETE",
    }
  );

  if (!response.ok) {
    throw new Error("Failed to delete event");
  }
};
  return (
    <EventContext.Provider
      value={{ events, categories, loading, setEvents, fetchData, deleteEvent, processCategories }}
    >
      {children}
    </EventContext.Provider>
  );
};