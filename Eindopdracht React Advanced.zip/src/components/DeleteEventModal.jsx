import { Button, Text, VStack, Dialog } from "@chakra-ui/react";

export const DeleteEventModal = ({
  open,
  cancel,
  finish,
  onClose
}) => {
  return (
    <Dialog.Root open={open} onOpenChange={cancel}>
      <Dialog.Backdrop />
      <Dialog.Positioner>
        <Dialog.Content>
          <Dialog.Header>Delete event</Dialog.Header>
          <Dialog.Body>
            <Text> Are you sure you want to delete the event?</Text>
          </Dialog.Body>

          <Dialog.Footer>
            <VStack w="full" spacing={3}>
              <Button
  onClick={async () => {
    await finish();
    onClose();
  }}
  variant="outline"
  width="full"
  type="button"
>
  Yes
</Button>
              <Button width="full" onClick={onClose}>
  No
</Button>
            </VStack>
          </Dialog.Footer>
        </Dialog.Content>
      </Dialog.Positioner>
    </Dialog.Root>
  );
};
