import { useForm } from "react-hook-form";
import {
  Button,
  Input,
  VStack,
  Field,
  Dialog,
} from "@chakra-ui/react";
import { toaster } from "../components/ui/toaster";
// import { useContext } from "react";

export const EditEventModal = ({ open, onClose, eventId, fetchData, processCategories}) => {

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm();




const onSubmit = async (data) => {
  try {
    const categoryIds = await processCategories(data.categoryIds);
    const response = await fetch(
      `http://localhost:3000/events/${eventId}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: data.title,
          description: data.description,
          image: data.image,
          startTime: data.startTime,
          endTime: data.endTime,
          location: data.location,
          categoryIds: categoryIds
        }),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to edit event");
    }

    await fetchData();

    toaster.create({
      title: "Success",
      description: "Event has been edited!",
      type: "success",
    });

    onClose();
  } catch (error) {
    console.error("Failed to edit event:", error);

    toaster.create({
      title: "Error",
      description: "Failed to edit event.",
      type: "error",
    });
  }
};


  


  return (
    <Dialog.Root open={open} onOpenChange={onClose}>
      <Dialog.Backdrop />
      <Dialog.Positioner>
        <Dialog.Content>
          <Dialog.Header>Edit event</Dialog.Header>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Dialog.Body>
              <Field.Root invalid={errors.title} mt={2}>
                <Field.Label>Title</Field.Label>
                <Input
                  type="input"
                  placeholder="Title"
                  {...register("title", {
                    required: "Please enter a title..",
                  })}
                />
                <Field.ErrorText>{errors.title?.message}</Field.ErrorText>
              </Field.Root>

              <Field.Root invalid={errors.description} mt={2}>
                <Field.Label>Description</Field.Label>
                <Input
                  type="input"
                  placeholder="Description"
                  {...register("description", {
                    required: "Please give a description of the event..",
                  })}
                />
                <Field.ErrorText>{errors.description?.message}</Field.ErrorText>
              </Field.Root>

              
            <Field.Root invalid={errors.image} mt={2}>
                <Field.Label>Image</Field.Label>
                <Input
                  type="input"
                  placeholder="url for an image, ex.: https://wincacademy.github.io/webpages/media/pexels-rnnzeravac-9273055.jpg"
                  {...register("image", {
                    required: "Please enter a valid url.",
                  })}
                />
                <Field.ErrorText>{errors.image?.message}</Field.ErrorText>
              </Field.Root>

              
              <Field.Root invalid={errors.startTime} mt={2}>
                <Field.Label>Start Time:</Field.Label>
                <Input
                  type="input"
                  placeholder="Time the event starts, in this format: 2026-10-19T18:00:00.000Z"
                  {...register("startTime", {
                    required: "Please enter a valid start time.",
                  })}
                />
                <Field.ErrorText>{errors.startTime?.message}</Field.ErrorText>
              </Field.Root>

              <Field.Root invalid={errors.endTime} mt={2}>
                <Field.Label>End Time:</Field.Label>
                <Input
                  type="input"
                  placeholder="Time the event ends, in this format: 2026-10-19T18:00:00.000Z"
                  {...register("endTime", {
                    required: "Please enter a valid end time.",
                  })}
                />
                <Field.ErrorText>{errors.endTime?.message}</Field.ErrorText>
              </Field.Root>
              <Field.Root invalid={errors.location} mt={2}>
                <Field.Label>Location:</Field.Label>
                <Input
                  type="input"
                  placeholder="Enter a location"
                  {...register("location", {
                    required: "Entering a location is required.",
                  })}
                />
                <Field.ErrorText>{errors.location?.message}</Field.ErrorText>
              </Field.Root>
            <Field.Root invalid={errors.categoryIds} mt={2}>
                <Field.Label>Category/Categories:</Field.Label>
                <Input
                  type="input"
                  placeholder="the category/categories this event belongs to, seperated by a comma"
                  {...register("categoryIds", {
                    required: "Entering a or multiple categories for this event is required.",
                  })}
                />
                <Field.ErrorText>{errors.categoryIds?.message}</Field.ErrorText>
              </Field.Root>

            </Dialog.Body>

            <Dialog.Footer>
              <VStack w="full" spacing={3}>

                <Button
                  type="submit"
                  colorScheme="blue"
                  isLoading={isSubmitting}
                  width="full"
                  eventId={eventId}
                >
                  Submit changes
                </Button>

                                <Button
                  onClick={onClose}
                  variant="outline"
                  width="full"
                  type="button"
                >
                  Cancel editing event
                </Button>
              </VStack>
            </Dialog.Footer>
          </form>
        </Dialog.Content>
      </Dialog.Positioner>
    </Dialog.Root>
  );
}
