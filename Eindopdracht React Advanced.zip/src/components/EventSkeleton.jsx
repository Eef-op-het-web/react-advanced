import {
  Skeleton,
  SkeletonText,
  Card,
  Stack,
  VStack,
} from "@chakra-ui/react";



export const EventSkeleton = () => {
  return (
    <Card.Root
      borderRadius="lg"
      w="full"
      h="full"
      variant="elevated"
      borderWidth={1}
      borderStyle="solid"
      borderColor="purple.700"
      bg="purple.100"
      overflow="hidden"
    >
      <Card.Body>
        <Stack spacing={2}>
          <SkeletonText noOfLines={1} spacing={2} />

          <Skeleton height="240px" width="100%" borderRadius="md" />
          <Stack minH="140px" spacing={3}>
            <SkeletonText noOfLines={3} spacing={2} />
          </Stack>

          <VStack spacing={2} align="stretch">
            <SkeletonText noOfLines={2} spacing={2} />
          </VStack>
        </Stack>
      </Card.Body>
    </Card.Root>
  );
};
