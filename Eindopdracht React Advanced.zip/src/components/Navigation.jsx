import { Flex, Link, Button } from "@chakra-ui/react";
import { AddEventModal } from "./AddEventModal";
import { Toaster, toaster } from "./ui/toaster";
import { EventContext } from "../EventContext";
import { useContext } from "react";
import { useState } from "react";

export const Navigation = () => {
  const { fetchData, categories, setCategories, processCategories } = useContext(EventContext);
  const [isModalOpen, setIsModalOpen] = useState(false);
  return (
    <>
      <nav>
        <Flex gap={2}>
          <Button backgroundColor="purple.200" m={1}>
            <Link fontWeight="bold" color="purple.800" href="/">
              Events
            </Link>
          </Button>
          <Button backgroundColor="purple.200" m={1}>
            <Link
              fontWeight="bold"
              color="purple.800"
              onClick={() => setIsModalOpen(true)}
            >
              Add Event
            </Link>
          </Button>
          <Button backgroundColor="purple.200" m={1}>
            <Link fontWeight="bold" color="purple.800" href="/aboutus">
              About us
            </Link>
          </Button>
        </Flex>
      </nav>



      <AddEventModal
        open={isModalOpen}
        categories={categories}
        setCategories={setCategories}
        processCategories={processCategories}
        onClose={() => setIsModalOpen(false)}
finish={async () => {
    try {
      await fetchData();

      toaster.create({
        title: "Success",
        description: "Event has been added!",
        type: "success",
      });
    } catch (error) {
      console.error("Failed to create event:", error);
      toaster.create({
        title: "Error",
        description: "Failed to create event.",
        type: "error",
      });
    }
  }}
      />
      <Toaster />
    </>
  );
};
