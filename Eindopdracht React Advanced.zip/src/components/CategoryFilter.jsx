import { Checkbox, CheckboxGroup, Stack } from "@chakra-ui/react";

export const CategoryFilter = ({ selected, setSelected, categories}) => {

  
  return (
    <CheckboxGroup
      value={selected}
      onValueChange={setSelected}
    >

      
      <Stack direction={{base: "column", sm:"row"}} gap={5}>
        <Checkbox.Root value={categories[0].id}>
          <Checkbox.HiddenInput />
          <Checkbox.Control />
          <Checkbox.Label color="purple.800">
            Sports
          </Checkbox.Label>
        </Checkbox.Root>

        <Checkbox.Root value={categories[1].id}>
          <Checkbox.HiddenInput />
          <Checkbox.Control />
          <Checkbox.Label color="purple.800">
            Games
          </Checkbox.Label>
        </Checkbox.Root>

        <Checkbox.Root value={categories[2].id}>
          <Checkbox.HiddenInput />
          <Checkbox.Control />
          <Checkbox.Label color="purple.800">
            Relaxation
          </Checkbox.Label>
        </Checkbox.Root>
      </Stack>
    </CheckboxGroup>
  );
};