import {
  Card,
  Box,
  Stack,
  Text,
  Heading,
  Flex,
  Image,
  Tag,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";

export const EventCard = ({ event, categories }) => {
  const navigate = useNavigate();
  return (
    <>
      <Card.Root
        borderRadius="lg"
        w="full"
        h="full"
        cursor="pointer"
        variant="elevated"
        borderStyle="solid"
        borderWidth={1}
        borderColor="purple.700"
        _light={{ bg: "purple.100" }}
        _dark={{ color: "purple.800" }}
        onClick={() => navigate(`/event/${event.id}`)}
      >
        <Card.Body padding={0}>
          <Heading
            mt={2}
            _light={{ color: "purple.800" }}
            _dark={{ color: "purple.100" }}
            textAlign="center"
            fontStyle="bold"
            size={{ base: "md", md: "3xl" }}
            padding={3}
          >
            {event.title}
          </Heading>
          <Box w="full" borderRadius="lg">
            <Image
              src={event.image}
              w="full"
              h="15rem"
              objectFit="cover"
              borderRadius="lg"
              padding="1rem"
            />
          </Box>

          <Stack
            direction="column"
            alignItems="center"
            mt={{ base: 1, md: 1 }}
            gap={{ base: 1, md: 1 }}
            padding={1}
          >
            <Text
              fontSize="1.5rem"
              _light={{ color: "purple.800" }}
              _dark={{ color: "purple.100" }}
              fontStyle="bold"
              textAlign="center"
            >
              {event.description}
            </Text>
            <Text
              fontSize={20}
              _light={{ color: "purple.800" }}
              _dark={{ color: "purple.100" }}
            >
              Start Time: {event.startTime.slice(11, 16)}
            </Text>
            <Text
              fontSize={20}
              _light={{ color: "purple.800" }}
              _dark={{ color: "purple.100" }}
            >
              End Time: {event.endTime.slice(11, 16)}
            </Text>

            <Flex gap={2} wrap="wrap" mt={2} mb={2}>
              {event.categoryIds.map((categoryId) => (
                <Tag.Root
                  p={{ base: 1.5, md: 2 }}
                  size={{ base: "sm", md: "md" }}
                  variant="solid"
                  bg="blue.100"
                  color="blue.800"
                >
                  <Tag.Label>{categories[(categoryId-1)]?.name}</Tag.Label>
                </Tag.Root>
              ))}
            </Flex>
          </Stack>
        </Card.Body>
      </Card.Root>
    </>
  );
};
